﻿using System;
namespace task5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("input number");

            double n1 = Convert.ToDouble(Console.ReadLine());

            if (n1 > 1)
            {
                Console.WriteLine(1 / Math.Pow(1 + n1, 2));
            }

            if (n1 < 1)
            {
                Console.WriteLine(Math.Pow(Math.Pow(n1, 2) - 1, 2));
            }

            if (n1 == 1)
            {
                Console.WriteLine("0");
            }
        }
    }
}