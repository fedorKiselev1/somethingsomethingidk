﻿using System.Diagnostics;

namespace task1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("input 2 numbers");
            int n1 = Convert.ToInt32(Console.ReadLine());
            int n2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("choose operation: 1) add 2) subtract 3) multiply 4) divide 5) ostatok");
            int choose = Convert.ToInt32(Console.ReadLine());

            switch (choose)
            {
                case 1:
                    Console.WriteLine(n1 + n2);
                    break;
                case 2:
                    Console.WriteLine(n1 - n2);
                    break;
                case 3:
                    Console.WriteLine(n1 * n2);
                    break;
                case 4:
                    Console.WriteLine(n1 / n2);
                    break;
                case 5:
                    Console.WriteLine(n1 % n2);
                    break;
            }    
        }
    }
}