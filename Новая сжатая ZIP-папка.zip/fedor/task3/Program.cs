﻿using System;
namespace task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("input number");

            int n1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(n1 / Math.Sqrt(n1 * 2 + 1));
        }
    }
}