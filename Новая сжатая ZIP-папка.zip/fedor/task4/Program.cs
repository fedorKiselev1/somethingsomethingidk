﻿namespace task4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("input number");

            int n1 = Convert.ToInt32(Console.ReadLine());

            for (int i = n1; i > 0; i--)
            {
                for (int j = i; j > 0; j--)
                {
                    Console.Write(j-1);
                }
                Console.WriteLine();
            }
        }
    }
}