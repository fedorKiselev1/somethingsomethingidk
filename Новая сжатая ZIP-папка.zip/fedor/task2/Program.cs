﻿using System;
namespace task2

{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("input 5 numbers");
            int max = -2147483647;
            int min = 2147483647;
            /*
            int n1 = Convert.ToInt32(Console.ReadLine());
            int n2 = Convert.ToInt32(Console.ReadLine());
            int n3 = Convert.ToInt32(Console.ReadLine());
            int n4 = Convert.ToInt32(Console.ReadLine());
            int n5 = Convert.ToInt32(Console.ReadLine());

            int max = Math.Max(n1, n2);
            max = Math.Max(max, n3);
            max = Math.Max(max, n4);
            max = Math.Max(max, n5);

            int min = Math.Min(n1, n2);
            min = Math.Min(min, n3);
            min = Math.Min(min, n4);
            min = Math.Min(min, n5);

            Console.WriteLine($"max number is {max}");
            Console.WriteLine($"min number is {min}");
            */

            for (int i = 0; i < 5; i++)
            {
                max = Math.Max(Convert.ToInt32(Console.ReadLine()), max);
            }
            Console.WriteLine($"max number is {max}");
            Console.WriteLine("input 5 numbers");
            for (int i = 0; i < 5; i++)
            {
                min = Math.Min(Convert.ToInt32(Console.ReadLine()), min);
            }
            Console.WriteLine($"min number is {min}");
        }
    }
}